﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Management;
using System.Windows.Threading;
using Microsoft.Win32;
using System.IO;
using OpenHardwareMonitor.Hardware;
//using System.Management;

namespace HSMonitor
{
    public partial class MainWindow : Window
    {
        System.Windows.Threading.DispatcherTimer timer = new System.Windows.Threading.DispatcherTimer();

        public MainWindow()
        {
            InitializeComponent();
            timer.Tick += new EventHandler(Timer_Tick);
            timer.Interval += new TimeSpan(0, 0, 1);
            timer.Start();
            computer.Open();
            Videokartya();
            Memory();
            Hattertar();
            Gep();
            Operaciosrendszer();
            Programok();
            DispatcherTimerSample();
            Processzor();
            Audio();
            /*GetBattery(); Megpróbáltam egy olyat, hogy azt is mutassa egy laptopnál, hogy az akkumulátorja milyen állapotban van.
                            Ezt nem tudtam letesztelni, szóval nem biztos, hogy ezzel együtt is jól működne a program és minden lefutna, éppen ezért tettem csak megjegyzésbe. (így biztosan jól lefut a program.)
                            Azért hagytam benne a kódban, hátha így ezzel együtt jobb lesz a projekt érdemjegye.*/
            GetOSInfo();
         //   GetProcessorInfo();
            //CPUSpeed();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            GetTime();
        }

        private void GetTime()
        {
            DateTime date;
            date = DateTime.Now;
            LblClock.Text = date.ToShortTimeString() + "   " + date.ToShortDateString();
        }

        private void GetBattery()
        {
            System.Management.ManagementClass wmi = new System.Management.ManagementClass(" //Class//");
            var providers = wmi.GetInstances();

            foreach (var provider in providers)
            {
                int batteryStatus = Convert.ToInt16(provider["AkkumulátorStátusz"]);

                if (batteryStatus == 0)
                {
                    LblBatteryStatus.Text = "Akkumulátor állapota:" + " " + " Egyéb";
                }
                if (batteryStatus == 1)
                {
                    LblBatteryStatus.Text = "Akkumulátor állapota:" + " " + " Ismeretlen";
                }
                if (batteryStatus == 2)
                {
                    LblBatteryStatus.Text = "Akkumulátor állapota:" + " " + " Teljesen feltöltve";
                }
                if (batteryStatus == 3)
                {
                    LblBatteryStatus.Text = "Akkumulátor állapota:" + " " + " Alacsony";
                }
                if (batteryStatus == 4)
                {
                    LblBatteryStatus.Text = "Akkumulátor állapota:" + " " + " Kritikus";
                }
                if (batteryStatus == 5)
                {
                    LblBatteryStatus.Text = "Akkumulátor állapota:" + " " + " Töltés";
                }
                if (batteryStatus == 6)
                {
                    LblBatteryStatus.Text = "Akkumulátor állapota:" + " " + " Töltés és magas";
                }
                if (batteryStatus == 7)
                {
                    LblBatteryStatus.Text = "Akkumulátor állapota:" + " " + " Töltés és alacsony";
                }
                if (batteryStatus == 8)
                {
                    LblBatteryStatus.Text = "Akkumulátor állapota:" + " " + " Töltés és krtikus";
                }
                if (batteryStatus == 9)
                {
                    LblBatteryStatus.Text = "Akkumulátor állapota:" + " " + " Meghatározatlan";
                }
                if (batteryStatus == 10)
                {
                    LblBatteryStatus.Text = "Akkumulátor állapota:" + " " + " Részben feltöltött";
                }
            }
        }

        Computer computer = new Computer() { CPUEnabled = true, GPUEnabled = true, MainboardEnabled = true, RAMEnabled = true, HDDEnabled = true };
        List<string> adatok = new List<string>();
        List<string> programsave = new List<string>();
        public void DispatcherTimerSample()
        {
            DispatcherTimer timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromMilliseconds(800);  
            timer.Tick += timer_Tick;
            timer.Start();
        }

        void timer_Tick(object sender, EventArgs e)
        {
            CPUertek();
            Ramertek();
            Gpuertek();
            Lemez();
        }

        string[] tar = { "bytes", "KB", "MB", "GB", "TB",
                              "PB", "EB", "ZB", "YB" }; 
        public void Ramertek()
        {
            string memhasznalat = "";
            foreach (var hardwareItem in computer.Hardware)
            {
                if (hardwareItem.HardwareType == HardwareType.RAM)
                {
                    hardwareItem.Update();
                    foreach (IHardware subHardware in hardwareItem.SubHardware)
                        subHardware.Update(); 

                    foreach (var sensor in hardwareItem.Sensors)
                    {
                        if (sensor.SensorType == SensorType.Load)
                        {
                            memhasznalat += $"{Math.Round(sensor.Value.Value, 1):N0}%\r\n";
                            if (Math.Round(sensor.Value.Value, 1)<50)
                                ramprocessbar.Foreground = new SolidColorBrush(Color.FromRgb(36, 247, 36));
                            else if (Math.Round(sensor.Value.Value, 1) < 80)  
                                ramprocessbar.Foreground = new SolidColorBrush(Color.FromRgb(239, 255, 0));
                            else
                                ramprocessbar.Foreground = new SolidColorBrush(Color.FromRgb(253, 10, 10)); 
                            ramprocessbar.Value = Math.Round(sensor.Value.Value, 1);
                        } 
                    }
                }
            }
            ramload.Content = memhasznalat;
        }

        private void GetOSInfo()
        {
            System.Management.ManagementClass wmi = new System.Management.ManagementClass("Win32_ComputerSystem");
            var providers = wmi.GetInstances();

            foreach (var provider in providers)
            {
                string systemSku = provider["SystemSKUNumber"].ToString();
                LblSystemSKU.Text = "System Sku:" + " " + systemSku.ToString();
            }
        }
        public void Gpuertek()
        {
            string gpuho = "";
            string gpuhasznalat = "";
            foreach (var hardwareItem in computer.Hardware)
            {
                if (hardwareItem.HardwareType == HardwareType.GpuNvidia || hardwareItem.HardwareType == HardwareType.GpuAti)
                {
                    hardwareItem.Update();
                    foreach (var sensor in hardwareItem.Sensors)
                    {  
                        if (sensor.SensorType == SensorType.Temperature)
                        {
                            gpuho += $" {sensor.Value.Value}°C\r\n";
                            if (Math.Round(sensor.Value.Value, 1) < 50)
                                gpuprocessbar.Foreground = new SolidColorBrush(Color.FromRgb(20, 255, 20));
                            else if (Math.Round(sensor.Value.Value, 1) < 70)  
                                gpuprocessbar.Foreground = new SolidColorBrush(Color.FromRgb(253, 253, 48)); 
                            else 
                                gpuprocessbar.Foreground = new SolidColorBrush(Color.FromRgb(253, 23, 23));   
                            gpuprocessbar.Value = sensor.Value.Value; 
                        }  
                        else if(sensor.SensorType == SensorType.Load && sensor.Name == "GPU Memory")
                        {
                            gpuhasznalat += $"{Math.Round(sensor.Value.Value, 1):N0}%\r\n";
                        }   
                    }
                }
                videokartyaho.Content = gpuho;
            }
        }

        public void Lemez()
        {
            disks.Items.Clear();
            ManagementObjectSearcher gep = new ManagementObjectSearcher("SELECT * FROM Win32_LogicalDisk");
            foreach (var item in gep.Get())
            {
                long hasznalt = Convert.ToInt64(item["Size"]) - Convert.ToInt64(item["FreeSpace"]);
                disks.Items.Add(item["Name"] + " " + Meret(Convert.ToInt64(item["Size"])) + " / " + Meret(hasznalt) );
            }
            
        }

        
    //    public void GetProcessorInfo()
   //     {
    //        LblClockSpeed.Text = $"Current Clock Speed: {GetCpuSpeed()}";
            //uint currentsp = 0;
            //using (ManagementObject Mo = new ManagementObject("Win32_Processor.DevideID='CPU0'"))
          //  {
            //    currentsp = (uint)(Mo["CurrentClockSpeed"]);
       //         LblClockSpeed.Text = $"Current Clock Speed: {currentsp}";
         //   }
   //     }

     //   public uint GetCpuSpeed()
       // {
        //    var managementObject = new ManagementObject("Win32_Processor.Devide_ID='CPU0'");
           // var speed = (uint)(managementObject["CurrentClockSpeed"]);
       //     managementObject.Dispose();
           // return speed;
       // }
           /* System.Management.ManagementClass wmi = new System.Management.ManagementClass("Win32:Processzor");
            var searcher = new ManagementObjectSearcher("select MaxClockSpeed from Win32_Processor");*/

           //foreach (var item in searcher.Get())
            //{
              //  var clockSpeed = (uint)item["MaxClockSpeed"];
                ///*int procSpeed = Convert.ToInt32(provider["CurrentClockSpeed"]);
                //LblClockSpeed.Text = "Current Clock Speed" + " " + procSpeed.ToString() + "" + "MHz";*/
           // }
        
        

        public void Gep()
        {
            ManagementObjectSearcher gep = new ManagementObjectSearcher("SELECT * FROM Win32_Baseboard");  
            foreach (var item in gep.Get())
            {
                alaplaposszoveg.Content = $"{item["Manufacturer"]}";
                adatok.Add($"Számítógép: {item["Manufacturer"]}"); 
            }
        }

        public void Operaciosrendszer()
        {
            ManagementObjectSearcher gep = new ManagementObjectSearcher("SELECT * FROM Win32_OperatingSystem");
            foreach (var item in gep.Get())
            { 
                oprendsz.Content = $"{item["Caption"]}";
                adatok.Add($"Operációs rendszer: {item["Caption"]}");   
            }
        }

        public void CPUertek()
        {
            string procho = "";
            string prochasznalat = "";
            string oszzhasznalat = "";
            foreach (var hardwareItem in computer.Hardware)
            {
                if (hardwareItem.HardwareType == HardwareType.CPU) 
                { 
                    hardwareItem.Update();
                    foreach (var sensor in hardwareItem.Sensors)
                    {
                        if (sensor.SensorType == SensorType.Temperature)
                        { 
                            procho += $"{sensor.Name} = {sensor.Value.Value}°C\r\n";
                            if (sensor.Name == "CPU Package")
                            {
                                processzorhofok.Content = $"{sensor.Value.Value}°C"; 
                                if (Math.Round(sensor.Value.Value, 1) < 50)
                                    prochoprocessbar.Foreground = new SolidColorBrush(Color.FromRgb(31, 255, 61));
                                else if (Math.Round(sensor.Value.Value, 1) < 70)
                                    prochoprocessbar.Foreground = new SolidColorBrush(Color.FromRgb(231, 243, 55));
                                else
                                    prochoprocessbar.Foreground = new SolidColorBrush(Color.FromRgb(243, 19, 19));
                                prochoprocessbar.Value = sensor.Value.Value;
                            }
                        }
                        else if (sensor.SensorType == SensorType.Load)
                        {
                            prochasznalat += $"{sensor.Name} = {Math.Round(sensor.Value.Value, 1):N0}%\r\n";
                            if (sensor.Name == "CPU Total")
                            {
                                oszzhasznalat = $"{Math.Round(sensor.Value.Value, 1):N0}%";
                                if (Math.Round(sensor.Value.Value, 1) < 50)  
                                    procprocessbar.Foreground = new SolidColorBrush(Color.FromRgb(0, 255, 34));
                                else if (Math.Round(sensor.Value.Value, 1) < 80)
                                    procprocessbar.Foreground = new SolidColorBrush(Color.FromRgb(218, 239, 82)); 
                                else 
                                    procprocessbar.Foreground = new SolidColorBrush(Color.FromRgb(205, 28, 28)); 
                                procprocessbar.Value = Math.Round(sensor.Value.Value, 1);
                            }
                        }
                    }
                }
            }

            processzorhasznalat.Content = oszzhasznalat;
            procusage.Content = prochasznalat;
        }

        public void Processzor()
        {
            ManagementObjectSearcher processzor = new ManagementObjectSearcher("SELECT * FROM Win32_Processor");  
            foreach (var item in processzor.Get())
            {
                prociszoveg.Content = $"{item["Name"]}";
                procimagszoveg.Content = $"{item["ThreadCount"]}";
                adatok.Add($"Processzor: {item["Name"]}");
                adatok.Add($"Processzor magjainak száma: {item["ThreadCount"]}");
            } 
        }

        public void Videokartya()
        {
            adatok.Add("Videókártyák:");
            ManagementObjectSearcher videokartya = new ManagementObjectSearcher("SELECT * FROM Win32_VideoController");
            foreach (var item in videokartya.Get())
            {
                videokartyalista.Items.Add(item["Name"] + "   | " + Meret(Convert.ToInt64(item["AdapterRam"])));
                adatok.Add("  " + item["Name"] + "   | " + Meret(Convert.ToInt64(item["AdapterRam"])));  
            }
        }

        public void Memory()
        {
            adatok.Add("Memóriák:");
            ManagementObjectSearcher memory = new ManagementObjectSearcher("SELECT * FROM Win32_PhysicalMemory");
            foreach (var item in memory.Get())
            {
                string ddrtype = "";
                if (Convert.ToInt32(item["MemoryType"]) == 20)
                    ddrtype = $"DDR";
                else if (Convert.ToInt32(item["MemoryType"]) == 21)  
                    ddrtype = $"DDR2";
                else if (Convert.ToInt32(item["MemoryType"]) == 24)
                    ddrtype = $"DDR3";
                else if (Convert.ToInt32(item["MemoryType"]) == 26)
                    ddrtype = $"DDR4";
                ram.Items.Add($" {Convert.ToString(ddrtype)} {item["Manufacturer"]} {item["Tag"]} {Meret(Convert.ToInt64(item["Capacity"]))} {item["Speed"]} MHz");
                    adatok.Add("  " + Convert.ToString(ddrtype) + item["Manufacturer"] + item["Tag"] + " " + Meret(Convert.ToInt64(item["Capacity"])) + " " + item["Speed"] + "MHz");  
            }
        }

        private void disks_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        public void Hattertar()
        {
            adatok.Add("Háttértárak:");
            ManagementObjectSearcher disk = new ManagementObjectSearcher("SELECT * FROM Win32_DiskDrive");
            foreach (var item in disk.Get())
            {
                hattertarlist.Items.Add(item["Model"] + " " + Meret(Convert.ToInt64(item["Size"])) + " ");
                adatok.Add("  " + item["Model"] + " " + Meret(Convert.ToInt64(item["Size"])) + " ");  
               
            }
        }

        public void Audio()
        {
            adatok.Add("Audioeszközök:");
            ManagementObjectSearcher disk = new ManagementObjectSearcher("SELECT * FROM Win32_SoundDevice");
            foreach (var item in disk.Get())
            {
                    hang.Items.Add(item["Name"]);
                    adatok.Add("  " + Convert.ToString(item["Name"]));
            }
        }

        private void mentess_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog save = new SaveFileDialog();
            save.Title = "A számítógép adatainak mentése";
            save.Filter = "Szöveges állomány (*.txt)|*.txt|Minden állomány (*.*)|*.*";
            save.DefaultExt = ".txt";
            save.CheckPathExists = true;
            if (save.ShowDialog() == true)
            {
                for (int i = 0; i < adatok.Count; i++)
                {
                    File.AppendAllText(save.FileName, adatok[i] + Environment.NewLine);
                }
            }
        }

        public void Programok()
        {
            ManagementObjectSearcher prog = new ManagementObjectSearcher("SELECT * FROM Win32_Product");
            foreach (var item in prog.Get())
            { 
                programsave.Add($"{item["Name"]}    | {item["Version"]}");
            }
        }

        private string Meret(Int64 value)
        {
            if (value < 0) { return "-" + Meret(-value); }
            if (value == 0) { return "0.0 bytes"; }

            int mag = (int)Math.Log(value, 1024);
            decimal adjustedSize = (decimal)value / (1L << (mag * 10));

            return string.Format("{0:n1} {1}", adjustedSize, tar[mag]);
        }

        private void vidmemprocessbar_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {

        }

        private void procprocessbar_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {

        }

        private void ramprocessbar_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {

        }

        private void hattertarlist_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
